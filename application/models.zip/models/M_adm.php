<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_adm extends CI_Model {

	function get_adm(){
		$sql='
			SELECT
				L.layanan,
				A.*
			FROM
				tbl_adm AS A
			INNER JOIN tbl_layanan AS L ON A.id_layanan = L.id
			WHERE
				A.tahun = '.$this->session->userdata('tp').'
			ORDER BY
				L.id ASC,
				A.pembayaran ASC
		';
		return $this->db->query($sql)->result_array();
	}

	function get_adm_by_layanan($id_layanan){
		$arr_where=array(
			'tahun'			=> $this->session->userdata('tp'),
			'id_layanan'	=> $id_layanan
		);
		return $this->db->get_where('tbl_adm', $arr_where)->result_array();
	}

	function get_adm_terbayar_all($id_layanan, $niwb){
		$sql='
			SELECT
			Sum(B.bayar) AS bayar
			FROM
			tbl_adm_bayar AS B
			INNER JOIN tbl_adm AS A ON B.id_adm = A.id
			WHERE
			A.id_layanan = '.$id_layanan.' AND
			A.tahun = '.$this->session->userdata('tp').' AND
			B.niwb = '.$niwb.'
		
		';
		return $this->db->query($sql)->row('bayar');
	}

	function get_adm_terbayar($id_adm, $niwb){
		$sql='
			SELECT
			Sum(B.bayar) AS terbayar
			FROM
			tbl_adm_bayar AS B
			WHERE
			B.niwb = '.$niwb.' AND
			B.id_adm = '.$id_adm;
		return $this->db->query($sql)->row('terbayar');
	}

	function get_riwayat_pembayaran($niwb){
		$sql='
			SELECT
				B.id,
				B.niwb,
				B.id_adm,
				B.tanggal,
				B.bayar,
				B.ket,
				A.pembayaran
			FROM
				tbl_adm_bayar AS B
			INNER JOIN tbl_adm AS A ON B.id_adm = A.id
			WHERE
				A.tahun = '.$this->session->userdata('tp').' AND
				B.niwb = '.$niwb.'
			ORDER BY
				B.updated DESC
		';
		return $this->db->query($sql)->result_array();
	}

	function update_pembayaran(){
		$arr_data=array(
			'tahun'			=> $this->session->userdata('tp'),
			'id_layanan'	=> $this->input->post('id_layanan'),
			'pembayaran'	=> $this->input->post('pembayaran'),
			'nominal'		=> $this->input->post('nominal')
		);
		$arr_where=array(
			'id'			=> $this->input->post('id')
		);
		
		if($this->input->post('mode')=='Tambah Pembayaran'){
			if($this->pembayaran_exists($arr_data['tahun'], $arr_data['id_layanan'], $arr_data['pembayaran'])){
				return 'Data ganda';
				
			}else{
				return $this->db->insert('tbl_adm', $arr_data);
			}
			
		}else{
			return $this->db->update('tbl_adm', $arr_data, $arr_where);			
		}
	}

	function pembayaran_exists($tahun, $id_layanan, $pembayaran){
		$arr_where=array(
			'tahun'			=> $tahun,
			'id_layanan'	=> $id_layanan,
			'pembayaran'	=> $pembayaran
		);
		$cnt = $this->db->get_where('tbl_adm', $arr_where)->num_rows();
		return $cnt>0;
	}
	function hapus_pembayaran($id){
		$arr_where=array(
			'id'			=> $id
		);
		return $this->db->delete('tbl_adm', $arr_where);
	}
	function simpan_pembayaran_wb(){
		$arr_data=array(
			'niwb'		=> $this->input->post('niwb'),
			'id_adm'	=> $this->input->post('id_adm'),
			'tanggal'	=> date('Y-m-d'),
			'bayar'		=> $this->input->post('bayar'),
			'ket'		=> $this->input->post('ket')
		);
		return $this->db->insert('tbl_adm_bayar', $arr_data);
	}
	
	function get_adm_by_niwb($niwb){
		$sql='
			SELECT
			A.id,
			A.pembayaran,
			A.nominal
			FROM
			tbl_adm AS A
			INNER JOIN tbl_layanan AS L ON A.id_layanan = L.id
			INNER JOIN tbl_kelas AS K ON K.id_layanan = L.id
			INNER JOIN tbl_kelas_anggota AS KA ON KA.id_kelas = K.id
			WHERE
			KA.niwb = '.$niwb.' AND
			A.tahun = '.$this->session->userdata('tp');
		return $this->db->query($sql)->result_array();
	}
}

?>
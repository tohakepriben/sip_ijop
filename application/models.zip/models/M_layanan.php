<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_layanan extends CI_Model {

	function get_all($tahun=0){
		if($tahun>0){
			$sql='
				SELECT L.*
				FROM tbl_layanan AS L
				INNER JOIN tbl_kelas AS K ON K.id_layanan = L.id
				WHERE K.tahun = '.$this->session->userdata('tp').' GROUP BY L.layanan';
			return $this->db->query($sql)->result_array();
			
		}else{
			return $this->db->get('tbl_layanan')->result_array();
		}
	}

	function insert(){
		$arr_data=array(
			'layanan'		=> $this->input->post('layanan'),
			'keterangan'	=> $this->input->post('keterangan')
		);
		return $this->db->insert('tbl_layanan', $arr_data);
	}

	function update($id_layanan){
		$arr_data=array(
			'layanan'		=> $this->input->post('layanan'),
			'keterangan'	=> $this->input->post('keterangan')
		);
		$arr_where=array(
			'id'		=> $id_layanan
		);
		return $this->db->update('tbl_layanan', $arr_data, $arr_where);
	}

}

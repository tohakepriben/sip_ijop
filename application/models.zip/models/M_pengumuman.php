<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pengumuman extends CI_Model {

	function get_all($include_invisible=TRUE){
		if(!$include_invisible){
			$this->db->where('visible', 1);	
		}
		$this->db->order_by('id', 'desc');
		return $this->db->get('tbl_pengumuman')->result_array();
	}
	
	function get_pengumuman($id_pengumuman){
		$this->db->where('id', $id_pengumuman);	
		return $this->db->get('tbl_pengumuman')->result_array();
	}
	
	function insert(){
		$arr_data=array(
			'judul'		=> $this->input->post('judul'),
			'pengumuman'=> $this->input->post('pengumuman'),
			'visible'	=> $this->input->post('visible')
		);
		return $this->db->insert('tbl_pengumuman', $arr_data);
	}
	
	function update($id_pengumuman){
		$arr_data=array(
			'judul'		=> $this->input->post('judul'),
			'pengumuman'=> $this->input->post('pengumuman'),
			'visible'	=> $this->input->post('visible')
		);
		$arr_where=array(
			'id'		=> $id_pengumuman
		);
		return $this->db->update('tbl_pengumuman', $arr_data, $arr_where);
		
	}
	
	function hapus($id_pengumuman){
		$arr_where=array(
			'id'		=> $id_pengumuman
		);
		return $this->db->delete('tbl_pengumuman', $arr_where);
		
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_ref extends CI_Model {

	function get_pendidikan(){
		$sql='select pendidikan from tbl_ref where pendidikan <> "null"';
		return($this->db->query($sql)->result_array());
	}

	function get_pekerjaan(){
		$sql='select pekerjaan from tbl_ref where pekerjaan <> "null"';
		return($this->db->query($sql)->result_array());
	}

	function get_penghasilan(){
		$sql='select penghasilan from tbl_ref where penghasilan <> "null"';
		return($this->db->query($sql)->result_array());
	}


}

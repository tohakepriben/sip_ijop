<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_auth extends CI_Model {

	function get_admin($uname){
		$this->db->where('uname', $uname);
		return $this->db->get('tbl_user')->row_array();
	}

	function get_ptk($nipy){
		$this->db->where('nipy', $nipy);
		return $this->db->get('tbl_ptk')->row_array();
	}

	function get_wb($niwb){
		$this->db->where('niwb', $niwb);
		return $this->db->get('tbl_wb')->row_array();
	}


	function log_admin($uname){
		$arr_data=array(
			'last_login'	=> date('Y-m-d H:i:s')
		);
		$arr_where=array(
			'uname'			=> $uname
		);		
		return $this->db->update('tbl_user', $arr_data, $arr_where);
	}

	function log_ptk($nipy){
		$arr_data=array(
			'last_login'	=> date('Y-m-d H:i:s')
		);
		$arr_where=array(
			'nipy'			=> $nipy
		);		
		return $this->db->update('tbl_ptk', $arr_data, $arr_where);
	}

	function log_wb($niwb){
		$arr_data=array(
			'last_login'	=> date('Y-m-d H:i:s')
		);
		$arr_where=array(
			'niwb'			=> $niwb
		);		
		return $this->db->update('tbl_wb', $arr_data, $arr_where);
	}

}

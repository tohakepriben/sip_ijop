<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_kelas extends CI_Model {

	function insert(){
		if($this->exists($this->input->post('id_layanan'), $this->input->post('kelas'))){
			return 'Kelas sudah ada';
		}else{
			$arr_data=array(
				'tahun'			=> $this->session->userdata('tp'),
				'id_layanan'	=> $this->input->post('id_layanan'),
				'kelas'			=> $this->input->post('kelas'),
				'wali_kelas'	=> $this->input->post('wali_kelas'),
				'sk_wali_kelas'	=> $this->input->post('sk_wali_kelas')
			);
			return $this->db->insert('tbl_kelas', $arr_data);
		}
	}

	function update($id){
		$arr_data=array(
			'kelas'			=> $this->input->post('kelas'),
			'wali_kelas'	=> $this->input->post('wali_kelas'),
			'sk_wali_kelas'	=> $this->input->post('sk_wali_kelas')
		);

		$arr_where=array(
			'id'			=> $id
		);
		return $this->db->update('tbl_kelas', $arr_data, $arr_where);		
	}

	function delete($id){
		$arr_where=array(
			'id'			=> $id
		);
		return $this->db->delete('tbl_kelas', $arr_where);
/*		if ($this->db->_error_message()){
		    $msg = $this->db->_error_message();
		    echo $msg;
		}*/
	}

	function exists($id_layanan, $kelas){
		$arr_where=array(
			'tahun'			=> $this->session->userdata('tp'),
			'id_layanan'	=> $id_layanan,
			'kelas'			=> $kelas
		);
		
		$cnt = $this->db->get_where('tbl_kelas', $arr_where)->num_rows();
		return $cnt > 0;
	}

	function get_all($id_layanan=0){
		$sql='
			SELECT
			L.id AS id_layanan,
			L.layanan,
			K.id,
			K.kelas,
			K.wali_kelas AS nipy,
			K.sk_wali_kelas,
			P.nama AS wali_kelas
			FROM tbl_layanan AS L
			INNER JOIN tbl_kelas AS K ON L.id = K.id_layanan
			LEFT JOIN tbl_ptk AS P ON K.wali_kelas = P.nipy
			WHERE K.tahun = '.$this->session->userdata('tp');
		if($id_layanan>0){
			$sql=$sql.' AND L.id='.$id_layanan;
		}
		$sql=$sql.' ORDER BY L.id, K.id';
		
		return($this->db->query($sql)->result_array());
	}
	
	function get_sum_by_layanan($id_layanan){
		$query=$this->db->query('
			SELECT
				Count(KA.niwb) AS jml
			FROM
				tbl_kelas_anggota KA
			INNER JOIN tbl_kelas K ON KA.id_kelas = K.id
			INNER JOIN tbl_layanan L ON K.id_layanan = L.id
			WHERE
				K.tahun = '.$this->session->userdata('tp'). '
			AND 
				L.id = "'.$id_layanan.'"
		');

        return $query->row('jml');
	}

	function get_pembelajaran($id_kelas){
		$sql='
			SELECT
				KP.id,
				KP.id_kelas,
				KP.id_mapel,
				REF.id AS id_mapel,
				REF.mapel,
				P.nipy,
				P.nama,
				KP.sk_tutor,
				K.kelas
			FROM tbl_kelas_pembelajaran AS KP
			INNER JOIN tbl_ref AS REF ON KP.id_mapel = REF.id
			INNER JOIN tbl_ptk AS P ON KP.tutor = P.nipy
			INNER JOIN tbl_kelas AS K ON K.wali_kelas = P.nipy
			WHERE KP.id_kelas = '.$id_kelas.' 
			GROUP BY KP.id_mapel
			ORDER BY REF.mapel ASC

		';
		return($this->db->query($sql)->result_array());
	}	
	
	function get_mapel_belum_masuk_kelas($id_kelas){
		$sql='
			SELECT
			id, mapel
			FROM
			tbl_ref
			WHERE
			mapel <> "null" AND
			id NOT IN
			(
				SELECT
					KP.id_mapel
				FROM tbl_kelas_pembelajaran AS KP
				INNER JOIN tbl_ref AS REF ON KP.id_mapel = REF.id
				INNER JOIN tbl_kelas AS K ON K.id = KP.id_kelas
				WHERE KP.id_kelas = '.$id_kelas.' 

			)
			ORDER BY mapel
		';
		return($this->db->query($sql)->result_array());
	}		
	
	function get_kelas_by_id($id_kelas){
		$arr_where=array(
			'id'		=> $id_kelas
		);
		return $this->db->get_where('tbl_kelas', $arr_where)->result_array();
	}
	
	function get_layanan($id_kelas){
		$sql='
			SELECT
			L.*
			FROM
			tbl_kelas AS K
			INNER JOIN tbl_layanan AS L ON K.id_layanan = L.id
			WHERE
			K.id = "'.$id_kelas.'"
		';
		return $this->db->query($sql)->result_array();		
	}


    function get_anggota($id_kelas){
		$query = $this->db->query('
			SELECT
				W.niwb,
				tcase ( W.nama ) as nama,
				W.jk,
				W.tanggal_lahir,
				tcase ( W.alamat ) as alamat,
				
				K.id AS id_kelas,
				K.kelas,
				K.wali_kelas 
			FROM
				tbl_wb AS W
				LEFT JOIN tbl_kelas_anggota ka ON W.niwb = ka.niwb
				INNER JOIN tbl_kelas K ON ka.id_kelas = K.id 
			WHERE
				K.id = "'.$id_kelas.'"
			ORDER BY
				W.nama ASC
			');
 
        return $query->result_array();
    }
	
    function get_jumlah_anggota($id_kelas){
		$query = $this->db->query('
			SELECT
				Count(CASE WHEN W.jk="L" THEN 1 END) AS jml_l,
				Count(CASE WHEN W.jk="P" THEN 1 END) AS jml_p,
				Count(W.jk) AS jml_lp
			FROM
				tbl_wb W
			LEFT JOIN tbl_kelas_anggota KA ON W.niwb = KA.niwb
			INNER JOIN tbl_kelas K ON KA.id_kelas = K.id
			WHERE
				K.id = "'.$id_kelas.'"
			');
 
        return $query->result_array();
    }
	
	function tambah_anggota($id_kelas, $niwb){
		$ret='Gagal menambahkan anggota';
		$arr_data_ka=array(
			'id_kelas'	=> $id_kelas,
			'niwb'		=> $niwb
		);
		if($this->db->insert('tbl_kelas_anggota', $arr_data_ka)){
			$arr_data_wbr=array(
				'niwb'			=> $niwb,
				'id_kelas'		=> $id_kelas,
				'tahun_masuk'	=> $this->session->userdata('tp'),
				'tgl_masuk'		=> date('Y-m-d')
			);
			if($this->registrasi_exists($niwb)){
				$arr_where=array(
					'tahun_masuk'	=> $this->session->userdata('tp'),
					'niwb'			=> $niwb
				);
				$ret = $this->db->update('tbl_wb_registrasi', $arr_data_wbr, $arr_where);
				
			}else{
				$ret = $this->db->insert('tbl_wb_registrasi', $arr_data_wbr);
			}
		}

		return $ret;
	}
	
	function hapus_anggota($id_kelas, $niwb){
		$ret='Gagal mengeluarkan anggota';
		$arr_where_ka=array(
			'id_kelas'	=> $id_kelas,
			'niwb'		=> $niwb
		);
		if($this->db->delete('tbl_kelas_anggota', $arr_where_ka)){
			$arr_data_wbr=array(
				'id_kelas'		=> NULL
			);
			$arr_where_wbr=array(
				'tahun_masuk'	=> $this->session->userdata('tp'),
				'niwb'		=> $niwb
			);
			$ret = $this->db->update('tbl_wb_registrasi', $arr_data_wbr, $arr_where_wbr);
		}
		return $ret;
	}

	function registrasi_exists($niwb){
		$arr_where=array(
			'tahun_masuk'	=> $this->session->userdata('tp'),
			'niwb'			=> $niwb
		);
		$cnt=$this->db->get_where('tbl_wb_registrasi', $arr_where)->num_rows();
		return $cnt>0;
	}

	function tambah_pembelajaran(){
		$arr_data=array(
			'id_kelas'		=> $this->input->post('id_kelas'),
			'id_mapel'		=> $this->input->post('id_mapel'),
			'tutor'			=> $this->input->post('tutor'),
			'sk_tutor'		=> $this->input->post('sk_tutor')
		);
		return $this->db->insert('tbl_kelas_pembelajaran', $arr_data);
	}

	function edit_pembelajaran(){
		$arr_data=array(
			'id_mapel'		=> $this->input->post('id_mapel'),
			'tutor'			=> $this->input->post('tutor'),
			'sk_tutor'		=> $this->input->post('sk_tutor')
		);
		$arr_where=array(
			'id_kelas'		=> $this->input->post('id_kelas'),
			'id_mapel'		=> $this->input->post('id_mapel'),
		);
		return $this->db->update('tbl_kelas_pembelajaran', $arr_data, $arr_where);
	}
	
	function hapus_pembelajaran(){
		$arr_where=array(
			'id_kelas'		=> $this->input->get('id_kelas'),
			'id_mapel'		=> $this->input->get('id_mapel')
		);
		$ret1 = $this->db->delete('tbl_kelas_pembelajaran', $arr_where);
		$ret2 = $this->db->delete('tbl_nilai', $arr_where);
		return $ret1 AND $ret2;
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_nilai extends CI_Model {

	function get_nilai_wb($niwb, $id_kelas, $id_mapel){
		$query = $this->db->query('
			SELECT
			n.nilai
			FROM
			tbl_nilai AS n
			WHERE
			n.niwb = '.$niwb.' AND
			n.id_mapel = '.$id_mapel.' AND
			n.id_kelas = '.$id_kelas);
		return $query->row('nilai');
	}
	
	function edit_nilai_kelas($id_kelas){
		$arrwb=explode(',', $this->input->post('arrwb'));
		foreach($arrwb as $niwb){
			$arr_mapel=$this->m_kelas->get_pembelajaran($id_kelas);
			foreach($arr_mapel as $mapel){
				$id_mapel=$mapel['id_mapel'];
				$nilai=$this->input->post($niwb.'-'.$id_mapel);
				if($this->nilai_wb_exists($niwb, $id_kelas, $id_mapel)){
					$this->update_nilai_wb($niwb, $id_kelas, $id_mapel, $nilai);
				}else{
					$this->insert_nilai_wb($niwb, $id_kelas, $id_mapel, $nilai);
				}
			}
		}
		

	}
	
	function nilai_wb_exists($niwb, $id_kelas, $id_mapel){
		$arr_where=array(
			'niwb'		=> $niwb,
			'id_kelas'	=> $id_kelas,
			'id_mapel'	=> $id_mapel
		);
//		$sql='select * from tbl_nilai where niwb='.$niwb.' and id_kelas='.$id_kelas.' and id_mapel='.$id_mapel;
		$cnt=$this->db->get_where('tbl_nilai', $arr_where)->num_rows();
		return ($cnt>0);
	}

	function insert_nilai_wb($niwb, $id_kelas, $id_mapel, $nilai){
		$arr_data=array(
			'niwb'		=> $niwb,
			'id_kelas'	=> $id_kelas,
			'id_mapel'	=> $id_mapel,
			'nilai'		=> $nilai
		);
		return $this->db->insert('tbl_nilai', $arr_data);
	}

	function update_nilai_wb($niwb, $id_kelas, $id_mapel, $nilai){
		$arr_data=array(
			'nilai'		=> $nilai
		);
		$arr_where=array(
			'niwb'		=> $niwb,
			'id_kelas'	=> $id_kelas,
			'id_mapel'	=> $id_mapel
		);
		return $this->db->update('tbl_nilai', $arr_data, $arr_where);
	}

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_tutor extends CI_Model {

	function get_last_nipy(){
		$query=$this->db->query('select max(nipy) as lastnipy from tbl_ptk');
		$ret = $query->row('lastnipy');
		if($ret<420055101){
			$ret=420055101;
		}
		$ret++;
		return($ret);
	}

	function get_tutor($nipy){
		return $this->db->get_where('tbl_ptk', 'nipy='.$nipy)->result_array();
	}
	
	function get_aktif(){
		$query = $this->db->query('
				select 
					ptk.nipy, 
					ptk.nama, 
					ptk.jk, 
					ptk.tanggal_lahir, 
					concat(ptk.alamat, " ", ptk.kelurahan) as alamat,
					ptk.last_login, 
					ptk.locked, 
					pp.sk
				from tbl_ptk ptk
				inner join tbl_ptk_pertahun pp
				on ptk.nipy = pp.nipy
				where pp.tahun='.$this->session->userdata("tp").'
				order by ptk.nipy'
			);
		return($query->result_array());
	}
	function get_nonaktif(){
		$query = $this->db->query('
				select 
					ptk.nipy, 
					ptk.nama, 
					ptk.jk, 
					ptk.tanggal_lahir, 
					concat(ptk.alamat, " ", ptk.kelurahan) as alamat
				from tbl_ptk ptk
				where ptk.nipy not in
				(select nipy from tbl_ptk_pertahun where tahun='.$this->session->userdata("tp").')
				order by ptk.nipy'
			);
		return($query->result_array());
	}
	
	function nipy_exists($nipy){
		$cnt = $this->db->get_where('tbl_ptk', 'nipy='.$nipy)->num_rows();
		return $cnt>0;
	}
	
	function tambah(){
		if($this->nipy_exists($this->input->post('nipy'))){
			return FALSE;
		}
		$arr_tutor=array(
			'nipy'				=> $this->input->post('nipy'),
			'nuptk'				=> $this->input->post('nuptk'),
			'nama'				=> $this->input->post('nama'),
			'jk'				=> $this->input->post('jk'),
			'tempat_lahir'		=> $this->input->post('tempat_lahir'),
			'tanggal_lahir'		=> $this->input->post('tanggal_lahir'),
			'nik'				=> $this->input->post('nik'),
			'telepon'			=> $this->input->post('telepon'),
			'hp'				=> $this->input->post('hp'),
			'email'				=> $this->input->post('email'),

			'alamat'			=> $this->input->post('alamat'),
			'rt'				=> $this->input->post('rt'),
			'rw'				=> $this->input->post('rw'),
			'kelurahan'			=> $this->input->post('kelurahan'),
			'kecamatan'			=> $this->input->post('kecamatan'),
			'kabupaten'			=> $this->input->post('kabupaten'),
			'provinsi'			=> $this->input->post('provinsi'),
			'kode_pos'			=> $this->input->post('kode_pos'),

			'ayah'				=> $this->input->post('ayah'),

			'ibu'				=> $this->input->post('ibu'),

		);
		$ret1 = $this->db->insert('tbl_ptk', $arr_tutor);
		
		$array=array(
			'nipy'			=> $this->input->post('nipy'),
			'tahun'			=> $this->session->userdata('tp'),
			'sk'			=> $this->input->post('sk')
		);
		$ret2 = $this->db->insert('tbl_ptk_pertahun', $array);
		
		
		return($ret1 AND $ret2);
	}	

	
	function edit($nipy){
		$arr_tutor=array(
			'nuptk'				=> $this->input->post('nuptk'),
			'nama'				=> $this->input->post('nama'),
			'jk'				=> $this->input->post('jk'),
			'tempat_lahir'		=> $this->input->post('tempat_lahir'),
			'tanggal_lahir'		=> $this->input->post('tanggal_lahir'),
			'nik'				=> $this->input->post('nik'),
			'telepon'			=> $this->input->post('telepon'),
			'hp'				=> $this->input->post('hp'),
			'email'				=> $this->input->post('email'),

			'alamat'			=> $this->input->post('alamat'),
			'rt'				=> $this->input->post('rt'),
			'rw'				=> $this->input->post('rw'),
			'kelurahan'			=> $this->input->post('kelurahan'),
			'kecamatan'			=> $this->input->post('kecamatan'),
			'kabupaten'			=> $this->input->post('kabupaten'),
			'provinsi'			=> $this->input->post('provinsi'),
			'kode_pos'			=> $this->input->post('kode_pos'),

			'ayah'				=> $this->input->post('ayah'),

			'ibu'				=> $this->input->post('ibu'),

		);
		
		$arr_where=array(
			'nipy'			=> $nipy
		);
		
		return $this->db->update('tbl_ptk', $arr_tutor, $arr_where);
	}	

	function update_pengangkatan(){
		if(strlen(trim($this->input->post('sk')))==0){
			$arr_where=array(
				'tahun'		=> $this->session->userdata('tp'),
				'nipy'		=> $this->input->post('nipy')
			);
			return $this->db->delete('tbl_ptk_pertahun', $arr_where);
		
		}else{
			$arr_data=array(
				'sk'		=> $this->input->post('sk')
			);
			$arr_where=array(
				'tahun'		=> $this->session->userdata('tp'),
				'nipy'		=> $this->input->post('nipy')
			);
			
			if($this->pengangkatan_exists($this->session->userdata('tp'), $this->input->post('nipy'))){
				return $this->db->update('tbl_ptk_pertahun', $arr_data, $arr_where);
				
			}else{
				return $this->db->insert('tbl_ptk_pertahun', array_merge($arr_data, $arr_where));			
			}
			
		}
	}

	function pengangkatan_exists($tahun, $nipy){
		$arr_where=array(
			'tahun'		=> $tahun,
			'nipy'		=> $nipy
		);
		$cnt = $this->db->get_where('tbl_ptk_pertahun', $arr_where)->num_rows();
		return $cnt>0;
	}

}
?>
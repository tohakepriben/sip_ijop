<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model {

	function get_user($uname){
		return $this->db->get_where('tbl_user', 'uname="'.$uname.'"')->result_array();
	}

	function get_all(){
		return $this->db->get('tbl_user')->result_array();
	}

	function update_user($uname){
		$arr_data=array(
			'nama'		=> $this->input->post('nama'),
			'password'	=> md5($this->input->post('password'))
		);

		$arr_where=array(
			'uname'		=> $uname
		);
		
		return $this->db->update('tbl_user', $arr_data, $arr_where);
	}

}
